import java.util.Scanner;

public class Question19 {
    private int employeeId;
    private String name;
    private double salary;
    
    // Static variables
    private static int maxEmployees = 100;
    private static String companyName = "ABC Company";
    
    // Constructor to initialize employee information
    public Question19(int employeeId, String name, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.salary = salary;
    }
    
    // Static method to add employee
    public static void addEmployee(Question19[] employees, Question19 employee, int index) {
        if (index < maxEmployees) {
            employees[index] = employee;
            System.out.println("Employee added successfully.");
        } else {
            System.out.println("Cannot add more employees. Maximum limit reached.");
        }
    }
    
    // Static method to update employee details
    public static void updateEmployee(Question19[] employees, int employeeId, String newName, double newSalary) {
        for (Question19 emp : employees) {
            if (emp != null && emp.getEmployeeId() == employeeId) {
                emp.setName(newName);
                emp.setSalary(newSalary);
                System.out.println("Employee details updated successfully.");
                return;
            }
        }
        System.out.println("Employee not found.");
    }
    
    // Static method to display employee details
    public static void displayEmployees(Question19[] employees) {
        System.out.println("Employee Details:");
        for (Question19 emp : employees) {
            if (emp != null) {
                System.out.println("Employee ID: " + emp.getEmployeeId() + ", Name: " + emp.getName() + ", Salary: " + emp.getSalary());
            }
        }
    }
    
    // Getter and setter methods
    public int getEmployeeId() {
        return employeeId;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public void setSalary(double salary) {
        this.salary = salary;
    }
    
    public static int getMaxEmployees() {
        return maxEmployees;
    }
    
    public static String getCompanyName() {
        return companyName;
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Question19[] employees = new Question19[100]; // Array to store employee objects
        
        // Adding employees
        System.out.println("Adding employees...");
        for (int i = 0; i < 2; i++) { // Change 2 to the number of employees you want to add
            System.out.println("Enter details for Employee " + (i + 1) + ":");
            System.out.print("Employee ID: ");
            int empId = scanner.nextInt();
            System.out.print("Name: ");
            scanner.nextLine(); // Consume newline character
            String empName = scanner.nextLine();
            System.out.print("Salary: ");
            double empSalary = scanner.nextDouble();
            
            addEmployee(employees, new Question19(empId, empName, empSalary), i);
        }
        
        // Displaying employees
        displayEmployees(employees);
        
        // Updating employee details
        System.out.println("\nUpdating employee details...");
        updateEmployee(employees, 101, "Johnny", 55000); // You can change the employee ID and details here
        
        // Displaying employees after update
        System.out.println("\nEmployee details after update:");
        displayEmployees(employees);
        
        scanner.close();
    }
}
