
package javawork;


import java.util.Scanner;

class Circle {
    public static double calculateArea(double radius) {
        return Math.PI * radius * radius;
    }
}

class Rectangle {
    public static double calculateArea(double length, double width) {
        return length * width;
    }
}

class Triangle {
    public static double calculateArea(double base, double height) {
        return 0.5 * base * height;
    }
}

public class Question17 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Choose shape:");
        System.out.println("1. Circle");
        System.out.println("2. Rectangle");
        System.out.println("3. Triangle");
        int choice = scanner.nextInt();
        
        if (choice == 1) {
            System.out.print("Enter radius of the circle: ");
            double radius = scanner.nextDouble();
            System.out.println("Area of the circle: " + Circle.calculateArea(radius));
        } else if (choice == 2) {
            System.out.print("Enter length of the rectangle: ");
            double length = scanner.nextDouble();
            System.out.print("Enter width of the rectangle: ");
            double width = scanner.nextDouble();
            System.out.println("Area of the rectangle: " + Rectangle.calculateArea(length, width));
        } else if (choice == 3) {
            System.out.print("Enter base of the triangle: ");
            double base = scanner.nextDouble();
            System.out.print("Enter height of the triangle: ");
            double height = scanner.nextDouble();
            System.out.println("Area of the triangle: " + Triangle.calculateArea(base, height));
        } else {
            System.out.println("Invalid choice.");
        }
        
        scanner.close();
    }
}
