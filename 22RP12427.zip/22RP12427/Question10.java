
package javawork;


import java.util.Scanner;

public class Question10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter first number: ");
        double num1 = scanner.nextDouble();
        System.out.print("Enter second number: ");
        double num2 = scanner.nextDouble();

        Calculator calculator = new Calculator();
        
        System.out.println("Addition: " + calculator.addition(num1, num2));
        System.out.println("Subtraction: " + calculator.subtraction(num1, num2));
        System.out.println("Multiplication: " + calculator.multiplication(num1, num2));
        System.out.println("Division: " + calculator.division(num1, num2));
        
        scanner.close();
    }
}

class Calculator {
    public double addition(double num1, double num2) {
        return num1 + num2;
    }

    public double subtraction(double num1, double num2) {
        return num1 - num2;
    }

    public double multiplication(double num1, double num2) {
        return num1 * num2;
    }

    public double division(double num1, double num2) {
        if (num2 == 0) {
            System.out.println("Error: Cannot divide by zero");
            return 0;
        }
        return num1 / num2;
    }
}
