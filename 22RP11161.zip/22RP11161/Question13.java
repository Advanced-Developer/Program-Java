
package javawork;


import java.util.Scanner;

import java.util.Scanner;

public class Question13 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the maximum number of students: ");
        int maxStudents = scanner.nextInt();
        Student[] students = new Student[maxStudents];

        System.out.print("Enter the passing grade: ");
        double passingGrade = scanner.nextDouble();
        Student.setPassingGrade(passingGrade);
        
        for (int i = 0; i < maxStudents; i++) {
            System.out.println("Enter details for Student " + (i + 1) + ":");
            System.out.print("Student ID: ");
            int studentId = scanner.nextInt();
            System.out.print("Name: ");
            String name = scanner.next();
            System.out.print("Grade: ");
            double grade = scanner.nextDouble();
            
            students[i] = new Student(studentId, name, grade);
        }
        
        System.out.println("Student Details:");
        for (int i = 0; i < maxStudents; i++) {
            students[i].displayStudentInfo();
        }
        
        scanner.close();
    }
}

class Student {
    private int studentId;
    private String name;
    private double grade;
    private static double passingGrade;

    public Student(int studentId, String name, double grade) {
        this.studentId = studentId;
        this.name = name;
        this.grade = grade;
    }

    public static void setPassingGrade(double passingGrade) {
        Student.passingGrade = passingGrade;
    }

    public void displayStudentInfo() {
        System.out.println("Student ID: " + studentId + ", Name: " + name + ", Grade: " + grade);
        if (grade >= passingGrade) {
            System.out.println("Status: Passed");
        } else {
            System.out.println("Status: Failed");
        }
    }
}

