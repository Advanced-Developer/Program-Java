
package javawork;


import java.util.Scanner;

public class Question7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the maximum number of books a patron can borrow: ");
        int maxBooks = scanner.nextInt();
        Patron.setMaxBooks(maxBooks);

        System.out.print("Enter the late fee: ");
        double lateFee = scanner.nextDouble();
        Transaction.setLateFee(lateFee);

        System.out.print("Enter the number of patrons: ");
        int numPatrons = scanner.nextInt();
        Patron[] patrons = new Patron[numPatrons];
        for (int i = 0; i < numPatrons; i++) {
            System.out.println("Enter details for Patron " + (i + 1) + ":");
            System.out.print("Patron ID: ");
            int patronId = scanner.nextInt();
            System.out.print("Name: ");
            String name = scanner.next();
            patrons[i] = new Patron(patronId, name);
        }

        System.out.print("Enter the number of books: ");
        int numBooks = scanner.nextInt();
        Book[] books = new Book[numBooks];
        for (int i = 0; i < numBooks; i++) {
            System.out.println("Enter details for Book " + (i + 1) + ":");
            System.out.print("Book ID: ");
            int bookId = scanner.nextInt();
            System.out.print("Title: ");
            String title = scanner.next();
            System.out.print("Author: ");
            String author = scanner.next();
            books[i] = new Book(bookId, title, author);
        }

        System.out.print("Enter the number of transactions: ");
        int numTransactions = scanner.nextInt();
        Transaction[] transactions = new Transaction[numTransactions];
        for (int i = 0; i < numTransactions; i++) {
            System.out.println("Enter details for Transaction " + (i + 1) + ":");
            System.out.print("Transaction ID: ");
            int transactionId = scanner.nextInt();
            System.out.print("Book ID: ");
            int bookId = scanner.nextInt();
            System.out.print("Patron ID: ");
            int patronId = scanner.nextInt();
            transactions[i] = new Transaction(transactionId, bookId, patronId);
        }

        System.out.println("Transaction Details:");
        for (Transaction transaction : transactions) {
            transaction.displayTransactionInfo(books, patrons);
        }
        
        scanner.close();
    }
}

class Book {
    int bookId;
    String title;
    private String author;

    public Book(int bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }
}

class Patron {
    int patronId;
    String name;
    private static int maxBooks;

    public Patron(int patronId, String name) {
        this.patronId = patronId;
        this.name = name;
    }

    public static void setMaxBooks(int maxBooks) {
        Patron.maxBooks = maxBooks;
    }
}

class Transaction {
    private int transactionId;
    private int bookId;
    private int patronId;
    private static double lateFee;

    public Transaction(int transactionId, int bookId, int patronId) {
        this.transactionId = transactionId;
        this.bookId = bookId;
        this.patronId = patronId;
    }

    public static void setLateFee(double lateFee) {
        Transaction.lateFee = lateFee;
    }

    public void displayTransactionInfo(Book[] books, Patron[] patrons) {
        String bookTitle = "";
        String patronName = "";
        for (Book book : books) {
            if (book.bookId == this.bookId) {
                bookTitle = book.title;
                break;
            }
        }
        for (Patron patron : patrons) {
            if (patron.patronId == this.patronId) {
                patronName = patron.name;
                break;
            }
        }
        System.out.println("Transaction ID: " + transactionId + ", Book Title: " + bookTitle + ", Patron Name: " + patronName + ", Late Fee: $" + lateFee);
    }
}
