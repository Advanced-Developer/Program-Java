
package javawork;


import java.util.Scanner;

public class Question3 {
    private double balance;
    private static String location;
    private static double maxWithdrawalLimit;

    public Question3(double balance) {
        this.balance = balance;
    }

    public void withdraw(double amount) {
        if (amount <= maxWithdrawalLimit && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawal successful. Remaining balance: " + balance);
        } else {
            System.out.println("Withdrawal failed. Exceeded withdrawal limit or insufficient balance.");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the balance of the account: ");
        double balance = scanner.nextDouble();

        System.out.print("Enter the location of the ATM: ");
        scanner.nextLine(); // Consume newline character
        String location = scanner.nextLine();
        
        System.out.print("Enter the maximum withdrawal limit: ");
        double maxWithdrawalLimit = scanner.nextDouble();

        Question3 atm = new Question3(balance);
        atm.setLocation(location);
        atm.setMaxWithdrawalLimit(maxWithdrawalLimit);

        System.out.print("Enter the amount to withdraw: ");
        double amount = scanner.nextDouble();
        atm.withdraw(amount);
        
        scanner.close();
    }

    public static void setLocation(String loc) {
        location = loc;
    }

    public static void setMaxWithdrawalLimit(double limit) {
        maxWithdrawalLimit = limit;
    }
}
