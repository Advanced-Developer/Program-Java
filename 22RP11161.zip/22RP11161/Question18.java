
package javawork;


public class Question18 {
    public static void main(String[] args) {
        int[] arr1 = {1, 2, 3};
        int[] arr2 = {4, 5, 6};
        
        int[] result = concatenateArrays(arr1, arr2);
        
        // Print the concatenated array
        System.out.print("Concatenated Array: ");
        for (int num : result) {
            System.out.print(num + " ");
        }
    }
    
    // Static method to concatenate two arrays
    public static int[] concatenateArrays(int[] arr1, int[] arr2) {
        int len1 = arr1.length;
        int len2 = arr2.length;
        
        int[] result = new int[len1 + len2];
        
        // Copy elements of arr1 to result
        for (int i = 0; i < len1; i++) {
            result[i] = arr1[i];
        }
        
        // Copy elements of arr2 to result
        for (int i = 0; i < len2; i++) {
            result[len1 + i] = arr2[i];
        }
        
        return result;
    }
}
